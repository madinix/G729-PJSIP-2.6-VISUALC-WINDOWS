HOW TO INTEGRATE G729 in your current VisualStudio pjproject 2.6:

1. Unzip pjproject-2.6_G729.zip

2. Copy audio_codecs.c into your pjproject-2.6\pjmedia\src

3. Copy config.h into your pjproject-2.6\pjmedia\include

4. Copy g729.h into your pjproject-2.6\pjmedia\include

5. Copy g729.c into your pjproject-2.6\pjmedia\src

6. Copy pjmedia-codec.h into your pjproject-2.6\pjmedia

7. Copy directory bcg729 into your pjproject-2.6\pjmedia\src\pjmedia-codec

8. Add g729.h, g729.c and directory bcg729 into your project pjmedia_codec

9. Modify your config_site.h located at pjproject-2.6\pjlib\include\pj\ and add:

#define PJMEDIA_HAS_G729_CODEC	1


10. Rebuild your pjmedia_codec and samples project

11. Enjoy!



=============================================
Feel free to contact me at madinix@gmail.com
=============================================
